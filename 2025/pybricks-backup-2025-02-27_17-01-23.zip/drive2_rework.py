from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor, UltrasonicSensor, ForceSensor
from pybricks.parameters import Button, Color, Direction, Port, Side, Stop
from pybricks.robotics import DriveBase
from pybricks.tools import wait, StopWatch, run_task, multitask
from action_arc import action_arc
from yaw import Yaw
from pupdevices import PupDevices

hub = PrimeHub()

watch = StopWatch()

def drive2(pd):
    #DriveBase initialisieren
    default_speed = 600
    pd.drive_base.use_gyro(False)
    pd.imu.reset_heading(0)
    pd.drive_base.settings(straight_speed=default_speed, straight_acceleration=500)
    yaw = Yaw(hub, pd.left_motor, pd.right_motor, max_velocity=400)

    # Zur Taucherin
    pd.drive_base.straight(-180)
    yield True
    yaw(24)
    yield True
    pd.drive_base.straight(-370)
    yield True

    #Taucherin abliefern
    pd.action_front.run_angle(400, 325)
    yield True
    pd.drive_base.straight(55)
    yield True
    pd.action_front.run_angle(800, -325)
    yield True

    #Korallenknospen
    yaw(-23) #-20
    yield True
    pd.drive_base.straight(-45)
    yield True
    yaw(-22.5)
    pd.drive_base.straight(50)
    yield True

    #Korallenbaum
    yaw(90) # 90
    yield True
    pd.drive_base.straight(5) # -5
    yield True
    pd.action_back.run_angle(400, 575)
    yield True
    pd.action_back.run_angle(500, -200)
    yield True

    # Zum Schiffswrack
    yaw(70)
    yield True
    pd.drive_base.straight(135) # 90 # 110
    yield True
    yaw(90)
    yield True
    pd.drive_base.straight(-450) # -350 # -380
    pd.drive_base.straight(20) # 0
    
    # Shrimp
    pd.action_front.run_angle(900, 550)
    yield True
    pd.drive_base.straight(200)
    yield True
    yaw(35)
    yield True
    pd.drive_base.straight(550)
    yield False

if __name__ == "__main__":
    for element in  drive2(PupDevices()): pass